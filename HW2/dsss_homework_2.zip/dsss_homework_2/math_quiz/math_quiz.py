import random
def random_integer(min, max):
    """
    Args:
        min (int): lower bound of the number
        max (int): upper bound of the number
    Returns:
        (int) A Random integer between [min, max], including both the points.
    """
    #Choosing random integer between the min and max bound
    return random.randint(min, max)

def random_operator():
    """
    Args:
        None
    Returns:
        (str) A Random operator '+', '-' or '*'.
    """
    #Choose random operator for mathematical expression
    return random.choice(['+', '-', '*'])

def apply_operation(number1, number2, operator):
    """
    Args:
        number1 (int): first number
        number2 (int): second number
        operator (str): operator
    Returns:
        (str) The mathematical expression
        (int) The answer of the expression
    """
    #p is output of the mathematical expression
    p = f"{number1} {operator} {number2}"
    if operator == '+': 
        #Summation of two numbers
        a = number1 + number2
    elif operator == '-': 
        #Subtraction of two numbers
        a = number1 - number2
    else:
        #Multiplication of two numbers 
        a = number1 * number2
    #return of expression and answer
    return p, a

def math_quiz():
    """
    Runs a math quiz game with random arithmetic questions. The user is prompted to solve each question,
    and points are awarded for correct answers.

    Returns:
        None
    """
    #Initial score and total questions
    score = 0
    total_questions = 3

    print("Welcome to the Math Quiz Game!")
    print("You will be presented with math problems, and you need to provide the correct answers.")

    #Loop for total questions
    for _ in range(total_questions):
        #Choosing of random numbers and operator
        number1 = random_integer(1, 10); number2 = random_integer(1, 10); operator = random_operator()

        #Get the question and its answer
        question, answer = apply_operation(number1, number2, operator)

        #print the question and get the answer from user
        print(f"\nQuestion: {question}")

        while True:
            try:
                useranswer = input("Your answer: ")
                useranswer = int(useranswer)
                break
            except ValueError:
                print("Invalid Input, value must be an integer.")

        #check if user's answer is correct and add score for correct answer
        if useranswer == answer:
            print("Correct! You earned a point.")
            score += 1 #increment score by 1 for a correct answer
        else:
            print(f"Wrong answer. The correct answer is {answer}.")

    #Print the final score
    print(f"\nGame over! Your score is: {score}/{total_questions}")

# run the quize
if __name__ == "__main__":
    math_quiz()
