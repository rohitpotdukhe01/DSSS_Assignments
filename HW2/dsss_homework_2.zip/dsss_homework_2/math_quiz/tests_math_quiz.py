import unittest
from math_quiz import random_integer, random_operator, apply_operation

class TestMathGame(unittest.TestCase):

    def test_random_integer(self):
        # Test if random numbers generated are within the specified range
        min_val = 1
        max_val = 10
        for _ in range(1000):  # Test a large number of random values
            rand_num = random_integer(min_val, max_val)
            self.assertTrue(min_val <= rand_num <= max_val)

    def test_random_operator(self):
        # Ensure that the random operator generated is from one of '+', '-', or '*'
        allowed_operators = ['+', '-', '*']
        for _ in range(1000):  # Test multiple times
            operator = random_operator()
            self.assertIn(operator, allowed_operators)

    def test_apply_operation(self):
        # Setup test cases with sample inputs, operators, expected problems, and answers
        test_cases = [
            (3, 3, '+', '3 + 3', 6),
            (6, 4, '+', '6 + 4', 10),
            (5, 3, '*', '5 * 3', 15),
            (9, 1, '*', '9 * 1', 9),
            (5, 5, '-', '5 - 5', 0),
            (9, 7, '-', '9 - 7', 2)
        ]

        # Loop through each test case to check if the function returns the expected results
        for num1, num2, operator, expected_problem, expected_answer in test_cases:
            problem, answer = apply_operation(num1, num2, operator)
            self.assertEqual(problem, expected_problem)  # Test if the generated problem is correct
            self.assertEqual(answer, expected_answer)    # Test if the calculated answer matches expectation


if __name__ == "__main__":
    unittest.main()
